package com.example.xpathcontains;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://demoqa.com/text-box");
        driver.manage().window().maximize();

        // using "contains"
        WebElement username = driver.findElement(By.xpath("//input[contains(@placeholder, 'Full Name')]"));
        username.sendKeys("admin");

        //  using "starts-with"
        WebElement password = driver.findElement(By.xpath("//input[starts-with(@id, 'user')]"));
        password.sendKeys("admin@123!");

        //  using matching "exact text"
        WebElement login = driver.findElement(By.xpath("//button[contains(text(), 'Submit')]"));
        login.click();
        
        driver.quit();
    }
}


