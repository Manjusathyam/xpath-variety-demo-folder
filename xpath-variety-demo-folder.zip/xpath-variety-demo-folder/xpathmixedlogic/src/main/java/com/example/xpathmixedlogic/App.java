package com.example.xpathmixedlogic;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://www.saucedemo.com/");
        driver.manage().window().maximize();

        WebElement username = driver.findElement(By.xpath("//input[@data-test='username' and @id= 'user-name']"));
        username.sendKeys("admin");

        WebElement password = driver.findElement(By.xpath("//input[@placeholder='Password' or @name='password']"));
        password.sendKeys("admin@123!");

        WebElement login = driver.findElement(By.xpath("//input[@type='submit' and (@id='login-button' or @name='login-button')]"));
        login.click();
        
        driver.quit();
    }
}


