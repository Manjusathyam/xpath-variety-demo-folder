package com.example.xpathabsoultepath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://demoqa.com/text-box");
        driver.manage().window().maximize();

        WebElement fullname = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/form/div[1]/div[2]/input"));
        fullname.sendKeys("Sathyam");

        WebElement email = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/form/div[2]/div[2]/input"));
        email.sendKeys("sathyam@gmail.com");

        WebElement currentaddress = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/form/div[3]/div[2]/textarea"));
        currentaddress.sendKeys("kk nagar");

        WebElement permanentaddress = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/form/div[4]/div[2]/textarea"));
        permanentaddress.sendKeys("kk nagar");

        WebElement submit = driver.findElement(By.xpath("/html/body/div[2]/div/div/div/div[2]/div[2]/form/div[5]/div/button"));
        submit.click();

        
        driver.quit();
    }
}


//Note:
// Absolute XPath starts from the root (html) of the HTML document and follows the complete path down to the target element.
// Use browser’s Inspect → Copy → Copy full XPath, the absolute XPath may look like below line. paste this inside the xpath. That's it. 
// /html/body/div[2]/div/div/div[2]/div[2]/form/div[1]/div[2]/input
