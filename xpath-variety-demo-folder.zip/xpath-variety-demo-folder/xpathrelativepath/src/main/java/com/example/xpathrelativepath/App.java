package com.example.xpathrelativepath;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://demoqa.com/text-box");
        driver.manage().window().maximize();

        WebElement fullname = driver.findElement(By.xpath("//input[@id = 'userName']"));
        fullname.sendKeys("Sathyam");

        WebElement email = driver.findElement(By.xpath("//input[@id = 'userEmail']"));
        email.sendKeys("sathyam@gmail.com");

        WebElement currentaddress = driver.findElement(By.xpath("//textarea[@id = 'currentAddress']"));
        currentaddress.sendKeys("kk nagar");

        WebElement permanentaddress = driver.findElement(By.xpath("//textarea[@id = 'permanentAddress']"));
        permanentaddress.sendKeys("kk nagar");

        WebElement submit = driver.findElement(By.xpath("//button[text()='Submit']"));
        submit.click();

        
        driver.quit();
    }
}

//Note
// Relative XPath starts from anywhere in the document (usually a unique element or tag) 
// without starting from the root (/html/body/...).
// Relative XPath always starts with //. That // means:
// "Start searching anywhere in the document (not necessarily from the root)."