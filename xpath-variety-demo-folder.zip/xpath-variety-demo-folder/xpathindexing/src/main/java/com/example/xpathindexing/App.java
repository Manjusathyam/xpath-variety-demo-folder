package com.example.xpathindexing;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class App {
    public static void main(String[] args) {
        WebDriverManager.chromedriver().setup();
        WebDriver driver = new ChromeDriver();

        driver.get("https://demoqa.com/text-box");
        driver.manage().window().maximize();

        // step 1
        WebElement fullname = driver.findElement(By.xpath("//input[1]"));
        fullname.sendKeys("Sathyam");

        // step 2
        WebElement email = driver.findElement(By.xpath("(//input[@type='email'])[1]"));
        email.sendKeys("sathyam@gmail.com");

        // step 3
        WebElement currentaddress = driver.findElement(By.xpath("(//textarea)[1]"));
        currentaddress.sendKeys("kk nagar");

        // step 4
        WebElement permanentaddress = driver.findElement(By.xpath("(//textarea)[2]"));
        permanentaddress.sendKeys("kk nagar");

        WebElement submit = driver.findElement(By.xpath("(//button[@id='submit'])[1]"));
        submit.click();

        
        driver.quit();
    }
}


// Note - Different combinations we are using.

// In step 1/step 2 ->>   
// (XPath = ("Tag_name + [Index]"))   or  (XPath = ("Tag_name +([attribute])[Index]"))   
// eg: (By.xpath("//input[1]"));      or   (By.xpath("(//input[@type='email'])[1]"));

// In step 3  ->>  (XPath = ("Tag_name + [Index]"));
// eg: (By.xpath("(//textarea)[1]"));

// In step 4 ->> (XPath = ("Tag_name + ([attribute])[Index]"));
// eg: (By.xpath("(//button[@id='submit'])[1]"));